(function ($) {
"use strict";

/*--------------------------------------
	Mean Menu Active
----------------------------------------*/
$('header .main-menu').meanmenu({
	meanMenuContainer: '.header-area',
	meanScreenWidth: 768,
});
   
})(jQuery);	
